window.DATAFEATURES = [
  {
    kategori: 'Downloader',
    nama: 'Spotify Downloader',
    deskripsi: 'Downloader lagu via API',
    file_case: 'codes/downloader/spotify_case.js',
    file_cjs: 'codes/downloader/spotify_cjs.js',
    file_esm: 'codes/downloader/spotify_esm.js'
  }
];